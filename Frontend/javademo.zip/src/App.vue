<template>
  <div id="app">
    <router-view class="router-view" />
  </div>
</template>

<script>
export default {
  name: "App",
  components: {},
  beforeMount() {
    this.$router.push("/Login");
  },
};
</script>

<style>
body {
  margin: 0;
  padding: 0;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  display: flex;
  flex-direction: column;
}
.router-view {
  width: 100%;
  overflow: hidden;
}
</style>
